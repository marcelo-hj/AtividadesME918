#' Calcular KPI de Total de Vendas
#'
#' Calcula o total de vendas com base nos filtros aplicados e formata o número para visualização no dashboard.
#' @param cidade Cidade para filtrar os dados antes do cálculo.
#' @param tipo_consumidor Tipo do consumidor para filtrar os dados antes do cálculo.
#' @param filial Filial para filtrar os dados antes do cálculo.
#' @return Uma string do total de vendas formatado.
#' @export
kpi_total_venda = function(cidade = "Todos", tipo_consumidor = "Todos", filial = "Todos"){
  df = get_data(cidade=cidade, tipo_consumidor=tipo_consumidor, filial=filial)
  total_vendas = sum(df$Total)
  total_vendas_formatado = formatar_numero_dashboard(total_vendas)
  return(total_vendas_formatado)

}

#' Calcular KPI de Total de Pedidos
#'
#' Calcula o total de pedidos únicos com base nos filtros aplicados e formata o número para visualização no dashboard.
#' @inheritParams kpi_total_venda
#' @return Uma string do total de pedidos formatado.
#' @export
kpi_total_pedidos = function(cidade = "Todos", tipo_consumidor = "Todos", filial = "Todos"){
  df = get_data(cidade=cidade, tipo_consumidor=tipo_consumidor, filial=filial)
  total_pedidos = formatar_numero_dashboard(length(unique(df$`Invoice ID`)))
  return(total_pedidos)
}

#' Calcular KPI lucro
#'
#' Calcula o lucro com base nos filtros aplicados e formata o número para visualização no dashboard.
#' @inheritParams kpi_lucro
#' @return Uma string do lucro formatado.
#' @export

kpi_lucro = function(cidade = "Todos", tipo_consumidor = "Todos", filial = "Todos"){
  df = get_data(cidade=cidade, tipo_consumidor=tipo_consumidor, filial=filial)
  total_pedidos = formatar_numero_dashboard(sum(df$`gross income`))
  return(total_pedidos)
}
