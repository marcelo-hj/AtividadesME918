#' Formatar Número para Dashboard
#'
#' Esta função formata números para o formato de milhares com uma letra 'K' no final.
#' @param numero O número a ser formatado.
#' @return Uma string do número formatado para o dashboard.
#' @import tidyverse plotly
#' @export
formatar_numero_dashboard = function(numero) {
  return(sprintf("%sK", format(round(numero/1000, 1), dec=",")))
}

kpi_total_venda = function(cidade = "Todos", tipo_consumidor = "Todos", filial = "Todos"){
  df = get_data(cidade=cidade, tipo_consumidor=tipo_consumidor, filial=filial)
  total_vendas = sum(df$Total)
  total_vendas_formatado = formatar_numero_dashboard(total_vendas)
  return(total_vendas_formatado)

}
