#' Obter Dados Filtrados
#'
#' Esta função retorna um dataframe filtrado baseado em cidade, tipo de consumidor e filial.
#' @param cidade O nome da cidade para filtrar os dados. Se "Todos" ou NULL, não filtra por cidade.
#' @param tipo_consumidor O tipo de consumidor para filtrar os dados. Se "Todos" ou NULL, não filtra por tipo de consumidor.
#' @param filial A filial para filtrar os dados. Se "Todos" ou NULL, não filtra por filial.
#' @return Um dataframe filtrado baseado nos critérios de seleção fornecidos.
#' @import tidyverse plotly
#' @export
#' @examples
get_data <- function(cidade = "Todos", tipo_consumidor = "Todos", filial = "Todos") {

  if (is.null(getOption("df_supermarket"))) {
    print("Downloading dataframe...")
    id <- "1_loutdN0WvqC37k5VqdSyxdn2vXT26p-"
    df_return <- read_csv(sprintf("https://docs.google.com/uc?id=%s&export=download", id))
    options("df_supermarket"=df_return)
  } else {
    df_return <- options("df_supermarket")$df_supermarket
  }

  if (!is.null(cidade) & cidade != "Todos") {
    df_return <- df_return %>% filter(City == cidade)
  }
  if (!is.null(tipo_consumidor) & tipo_consumidor != "Todos") {
    df_return <- df_return %>% filter(`Customer type` == tipo_consumidor)
  }
  if (!is.null(filial) & filial != "Todos") {
    df_return <- df_return %>% filter(Branch == filial)
  }
  return(df_return)
}
