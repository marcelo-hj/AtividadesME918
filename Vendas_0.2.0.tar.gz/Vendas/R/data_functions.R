#' Obter Dados Filtrados
#'
#' Esta função retorna um dataframe filtrado baseado em cidade, tipo de consumidor e filial.
#' @param cidade O nome da cidade para filtrar os dados. Se "Todos" ou NULL, não filtra por cidade.
#' @param tipo_consumidor O tipo de consumidor para filtrar os dados. Se "Todos" ou NULL, não filtra por tipo de consumidor.
#' @param filial A filial para filtrar os dados. Se "Todos" ou NULL, não filtra por filial.
#' @return Um dataframe filtrado baseado nos critérios de seleção fornecidos.
#' @import tidyverse plotly
#' @export
#' @examples
#' get_data(cidade = "Naypyitaw", tipo_consumidor = "Member", filial = "A")
get_data <- function(cidade = "Todos", tipo_consumidor = "Todos", filial = "Todos") {
  df_return <- readRDS(file = ".\\data\\supermarket_sales.rds")

  if (!is.null(cidade) & cidade != "Todos") {
    df_return <- df_return %>% filter(City == cidade)
  }
  if (!is.null(tipo_consumidor) & tipo_consumidor != "Todos") {
    df_return <- df_return %>% filter(`Customer type` == tipo_consumidor)
  }
  if (!is.null(filial) & filial != "Todos") {
    df_return <- df_return %>% filter(Branch == filial)
  }
  return(df_return)
}
