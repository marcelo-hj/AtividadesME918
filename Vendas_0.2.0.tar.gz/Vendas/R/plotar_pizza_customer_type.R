# library(tidyverse)
# library(plotly)

#' Plotar Gráfico em Pizza de Tipos de Cliente
#'
#' Esta função gera um gráfico em pizza (ou gráfico de setores) dos tipos de cliente.
#' @param my_col Nome da coluna a ser utilizada para o gráfico em pizza.
#' @param cidade Cidade para filtrar os dados antes de plotar.
#' @param tipo_consumidor Tipo do consumidor para filtrar os dados antes de plotar.
#' @param filial Filial para filtrar os dados antes de plotar.
#' @return Um gráfico ggplot do gráfico em pizza gerado.
#' @export
plotar_pizza_customer_type = function(my_col, cidade = "Todos", tipo_consumidor = "Todos", filial = "Todos"){
  df = get_data(cidade=cidade, tipo_consumidor=tipo_consumidor, filial=filial)

  df_count <- df %>%
    group_by(across(all_of(my_col))) %>%
    summarise(count = n())

  df_count$fraction <- df_count$count / sum(df_count$count)
  df_count$ymax <- cumsum(df_count$fraction)
  df_count$ymin <- c(0, head(df_count$ymax, n = -1))
  df_count$labelPosition <- (df_count$ymax + df_count$ymin) / 2
  df_count$label <- paste0(df_count[[my_col]], "\n value: ", df_count$count)

  plot <- ggplot(df_count, aes(ymax = ymax, ymin = ymin, xmax = 4, xmin = 3, fill =  .data[[my_col]])) +
    geom_rect() +
    geom_label(x = 3.5, aes(y = labelPosition, label = label), size = 6) +
    scale_fill_brewer(palette = 4) +
    coord_polar(theta = "y") +
    xlim(c(2, 4)) +
    theme_void() +
    theme(legend.position = "none")
  return(plot)
}
