#' Plotar Vendas por Dia
#'
#' Esta função gera um gráfico de linha do rendimento por dia.
#' @param cidade Cidade para filtrar os dados antes de plotar.
#' @param tipo_consumidor Tipo do consumidor para filtrar os dados antes de plotar.
#' @param filial Filial para filtrar os dados antes de plotar.
#' @return Um objeto plotly do gráfico gerado.
#' @export
plotar_vendas_por_dia = function(cidade = "Todos", tipo_consumidor = "Todos", filial = "Todos") {
  df = get_data(cidade=cidade, tipo_consumidor=tipo_consumidor, filial=filial)

  df <- df %>%
    mutate(renda = `Unit price`*Quantity) %>%
    group_by(City)

  renda_por_dia <- data.frame(xtabs(formula=renda~Date, data = df))
  renda_por_dia$Date <- as.Date(renda_por_dia$Date)

  plot_rendimento <- renda_por_dia %>%
    ggplot(data = renda_por_dia, mapping = aes(x = Date, y = Freq)) +
    geom_line() +
    geom_point() +
    geom_smooth(method = "lm", se = FALSE, formula = 'y ~ x') +
    ggtitle("Séries Temporais do rendimento por dia") +
    xlab("Data")+ ylab("Total de rendimento")
  return(ggplotly(plot_rendimento))
}
