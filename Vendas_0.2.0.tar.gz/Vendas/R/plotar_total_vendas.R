#' Plotar Total de Vendas
#'
#' Esta função gera um gráfico de barras do total de vendas por mês.
#' @param cidade Cidade para filtrar os dados antes de plotar.
#' @param tipo_consumidor Tipo do consumidor para filtrar os dados antes de plotar.
#' @param filial Filial para filtrar os dados antes de plotar.
#' @return Um objeto plotly do gráfico gerado.
#' @export
plotar_total_vendas = function(cidade = "Todos", tipo_consumidor = "Todos", filial = "Todos"){
  df = get_data(cidade=cidade, tipo_consumidor=tipo_consumidor, filial=filial)

  plot = df %>%
    group_by(format(Date, format = "%Y-%m")) %>%
    summarise(total = sum(Total)) %>%
    ggplot(aes(x=`format(Date, format = "%Y-%m")`, y=total)) +
    geom_bar(stat = "identity") +
    labs(title = paste0("Total de Vendas - ", cidade), y="", x="")
  return(ggplotly(plot))
}
